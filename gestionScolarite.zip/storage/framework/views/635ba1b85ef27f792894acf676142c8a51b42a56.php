<?php $__env->startSection('content'); ?>
    <div class="row col-lg-12">
        <div class="card align-content-lg-center shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Liste des Cours</h6>
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <div class="dataTables_length" id="dataTable_length">
                                <label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div id="dataTable_filter" class="dataTables_filter">
                                <label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable"></label>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(route('cours.create')); ?>" class="btn btn-success">Ajouter</a>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Classe</th>
                                <th>Matiere(EC)</th>
                                <th>Salle</th>
                                <th>Nom du cours</th>
                                <th>Desc du cours</th>
                                <th>Heure Debut</th>
                                <th>Heure Fin</th>
                                <th>Duree</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td> <?php echo e($cour->idcours); ?> </td>
                                <td> <?php echo e($cour->classe->nomclasse); ?> </td>
                                <td> <?php echo e($cour->ec->nomec); ?> </td>
                                <td> <?php echo e($cour->salle->nomsalle); ?> </td>
                                <td><?php echo e($cour->nomcours); ?></td>
                                <td><?php echo e($cour->desccours); ?></td>
                                <td><?php echo e($cour->duree); ?></td>
                                <td><?php echo e($cour->heuredebut); ?></td>
                                <td><?php echo e($cour->heurefin); ?></td>
                                <td class="btn btn-primary"><a class="btn-primary" href="<?php echo e(route('cours.edit', $cour->idcours )); ?>">Modifier</a></td>

                                <form action="<?php echo e(route('cours.destroy', $cour->idcours )); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <th class="btn btn-danger"> <button onclick="return confirm('Voulez-vous vraiment supprimer')" type="submit" class="btn-danger">Supprimer</button></th>

                                </form>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LAMZO\Documents\stage\gestionScolarite\resources\views/cours/index.blade.php ENDPATH**/ ?>