<?php $__env->startSection('content'); ?>
    <div class="align-content-md-center">

        <div class="card text-left">
            <div class="card-header">Formulaire de modification d'une Annee scolaire</div>
          <div class="card-body">
            <form method="post" action="<?php echo e(route('annee.update', $annee->idannescolaire)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                

                <div class="form-group">
                  <label for="anneescolaire">Annee Scolaire</label>
                  <input type="text" name="anneescolaire" value="<?php echo e($annee->anneescolaire); ?>" class="form-control <?php $__errorArgs = ['anneescolaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="anneescolaire" placeholder="Entrer l'annee">
                    <?php $__errorArgs = ['anneescolaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="statut">Statut</label>
                    <select name="statut" class="form-control <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="statut">

                        <?php if($annee->statut=='En cours'): ?>

                        <option><?php echo e($annee->statut); ?></option>
                        <option>Termine</option>
                        <option>Non valide</option>
                        <?php endif; ?>
                        <?php if($annee->statut=='Termine'): ?>

                        <option><?php echo e($annee->statut); ?></option>
                        <option>Non valide</option>
                        <option>En cours</option>

                        <?php endif; ?>
                        <?php if($annee->statut=='Non valide'): ?>

                        <option><?php echo e($annee->statut); ?></option>
                        <option>Termine</option>
                        <option>En cours</option>

                        <?php endif; ?>

                      <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </select>
                  </div>
                <button type="submit" class="btn btn-primary">Modifier l'annee</button>
            </form>
          </div>
        </div>

    <div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LAMZO\Documents\stage\gestionScolarite\resources\views/annee/edit.blade.php ENDPATH**/ ?>