<?php $__env->startSection('content'); ?>
    <div class="row col-lg-12">
        <div class="card align-content-lg-center shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Liste des Paiements</h6>
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <div class="dataTables_length" id="dataTable_length">
                                <label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div id="dataTable_filter" class="dataTables_filter">
                                <label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable"></label>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(route('paiement.create')); ?>" class="btn btn-success">Ajouter</a>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Mode Paiement</th>
                                <th>Mat etudiant</th>
                                <th>Montant</th>
                                <th>Date Paiement</th>
                                <th>Mois</th>
                                <th>Libelle</th>
                                <th>Observation</th>
                                <th style="width: 200px;">Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Mode Paiement</th>
                                <th>Mat etudiant</th>
                                <th>Montant</th>
                                <th>Date Paiement</th>
                                <th>Mois</th>
                                <th>Libelle</th>
                                <th>Observation</th>
                                <th style="width: fit-content;">Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td> <?php echo e($paiement->idpaiement); ?> </td>
                                <td> <?php echo e($paiement->modePaiement->libellemodepaiement); ?> </td>
                                <td> <?php echo e($paiement->etudiant->matricule); ?> </td>
                                <td> <?php echo e($paiement->montant); ?> </td>
                                <td> <?php echo e($paiement->datepaiement); ?> </td>
                                <td>
                                <?php $__currentLoopData = json_decode($paiement->mois); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($moi); ?>

                                    <?php if(!$loop->last): ?>
                                        ,
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($paiement->libelle); ?></td>
                                <td><?php echo e($paiement->observation); ?></td>
                                <td >
                                    <a class="btn-primary" href="<?php echo e(route('paiement.edit', $paiement->idpaiement )); ?>">Modifier</a>
                                    <a class="btn-success" href="<?php echo e(route('recu', $paiement->idpaiement)); ?>"> <i class="fas fa-print"></i> Imprimer</a> <br>
                                    <form action="<?php echo e(route('paiement.destroy', $paiement->idpaiement )); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?> <button onclick="return confirm('Voulez-vous vraiment supprimer')" type="submit" class="btn-danger">Supprimer</button>

                                    </form>
                                </td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LAMZO\Documents\stage\gestionScolarite\resources\views/paiement/index.blade.php ENDPATH**/ ?>